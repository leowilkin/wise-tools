# Security Policy

This extension doesn't do anything with the ID, apart from copy it to clipboard. No network calls are made. Your sh\*t is your sh\*t, seriously.

Somehow find a vulnerability? You're either bugging, or something's gone really _really_ wrong! Drop an issue, or send me an email at leo [at] wilkin [dot] xyz.